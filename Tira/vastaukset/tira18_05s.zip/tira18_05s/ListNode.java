class ListNode {
    public ListNode() {
		this.data = 0;
		this.next = null;
    }
    public int      data;
    public ListNode next;
}
