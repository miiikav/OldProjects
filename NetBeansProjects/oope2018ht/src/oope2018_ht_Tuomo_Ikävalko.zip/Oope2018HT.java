
import oope2018ht.Kayttoliittyma;

/**
 * <p>
 * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2018.
 * <p>
 * @author Tuomo Ikävalko (Ikavalko.Tuomo.J@student.uta.fi)
 */
public class Oope2018HT {

    /** Ohjelman main metodi, jonka ainoa tehtävä on kutsua käyttöliittymää.
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Kayttoliittyma testi = new Kayttoliittyma();
        testi.Paasilmukka();
    }
    
}
